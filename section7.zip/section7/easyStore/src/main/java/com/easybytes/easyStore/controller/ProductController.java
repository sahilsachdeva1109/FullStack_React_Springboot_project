package com.easybytes.easyStore.controller;

import com.easybytes.easyStore.Repository.ProductRepo;
import com.easybytes.easyStore.entity.Product;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("api/v1/products")
@RequiredArgsConstructor
public class ProductController {

    private  final ProductRepo productRepo;


    @GetMapping
    public List<Product> getProducts(){
        List<Product> productList = productRepo.findAll();
        return productList;
    }

}
